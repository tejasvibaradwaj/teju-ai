package com.tejasvi.voiceassistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var conversation: TextView
    private lateinit var apiKey: EditText
    private val http = OkHttpClient()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val prefs by lazy { getSharedPreferences("assistant", MODE_PRIVATE) }

    private var history = JSONArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.statusText)
        conversation = findViewById(R.id.conversationText)
        apiKey = findViewById(R.id.apiKeyInput)

        val saved = prefs.getString("api_key", "") ?: ""
        apiKey.setText(saved)

        tts = TextToSpeech(this, this)

        findViewById<Button>(R.id.saveKeyButton).setOnClickListener {
            val key = apiKey.text.toString().trim()
            prefs.edit().putString("api_key", key).apply()
            status.text = if (key.isBlank()) "API key removed" else "API key saved"
        }

        findViewById<Button>(R.id.micButton).setOnClickListener { listen() }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : SimpleRecognitionListener() {
            override fun onResults(results: Bundle) {
                val text = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) ask(text)
                else status.text = "I didn't catch that."
            }
            override fun onError(error: Int) {
                status.text = "Couldn't hear you. Tap again."
            }
        })

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun listen() {
        if (prefs.getString("api_key", "").isNullOrBlank()) {
            status.text = "Save your OpenAI API key first."
            apiKey.requestFocus()
            return
        }
        status.text = "Listening…"
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        speechRecognizer.startListening(intent)
    }

    private fun ask(userText: String) {
        status.text = "Thinking…"
        conversation.append("\n\nYou: $userText")
        scope.launch {
            try {
                val answer = withContext(Dispatchers.IO) { callOpenAI(userText) }
                conversation.append("\n\nTejasvi AI: $answer")
                status.text = "Ready"
                tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "reply")
            } catch (e: Exception) {
                status.text = "Error"
                conversation.append("\n\nError: ${e.message ?: "Unknown error"}")
            }
        }
    }

    private fun callOpenAI(userText: String): String {
        val key = prefs.getString("api_key", "") ?: error("Missing API key")

        // Responses API. The app uses the current GPT-5.6 Luna model by default.
        val body = JSONObject().apply {
            put("model", "gpt-5.6-luna")
            put("instructions", """
                You are Tejasvi's personal Android voice assistant.
                Be helpful, concise, friendly and natural for spoken conversation.
                You can answer questions, explain things, help with studies, cricket and everyday tasks.
                Do not claim to have performed an Android action unless the app actually performed it.
            """.trimIndent())
            put("input", userText)
        }

        val request = Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .addHeader("Authorization", "Bearer $key")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(request).execute().use { response ->
            val raw = response.body?.string() ?: ""
            if (!response.isSuccessful) error("OpenAI API ${response.code}: $raw")
            val json = JSONObject(raw)

            // Responses API commonly exposes the final text through output[].content[].text.
            val output = json.optJSONArray("output") ?: return json.optString("output_text", "No response")
            for (i in 0 until output.length()) {
                val item = output.optJSONObject(i) ?: continue
                val content = item.optJSONArray("content") ?: continue
                for (j in 0 until content.length()) {
                    val part = content.optJSONObject(j) ?: continue
                    val text = part.optString("text", "")
                    if (text.isNotBlank()) return text
                }
            }
            return json.optString("output_text", "I couldn't generate a response.")
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale.getDefault()
            tts.setSpeechRate(1.0f)
        }
    }

    override fun onDestroy() {
        speechRecognizer.destroy()
        tts.stop()
        tts.shutdown()
        scope.cancel()
        super.onDestroy()
    }
}