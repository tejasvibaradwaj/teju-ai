# Tejasvi AI — Android Voice Assistant

A starter Jarvis-style Android assistant:
- voice input using Android SpeechRecognizer
- AI replies using the OpenAI Responses API
- spoken replies using Android TextToSpeech
- API key stored locally in Android app preferences
- clean dark UI

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone with USB debugging enabled.
4. Run the `app` configuration.
5. Grant microphone permission.
6. Enter your OpenAI API key and tap **Save API Key**.
7. Tap **TAP TO TALK**.

## Important security note
For a personal prototype, entering the key on-device is convenient, but an API key embedded in or supplied to a client app is not a secure production architecture. For a public app, put the OpenAI API behind your own authenticated backend.

## Next upgrades
- wake word / always-listening mode
- streaming voice replies
- conversation persistence
- web search
- Android intents for opening apps/settings
- alarms/reminders
- configurable assistant name and voice
- safer action-confirmation layer